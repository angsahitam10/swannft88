CREATE TABLE network_config (
    id     SERIAL PRIMARY KEY,
    config JSONB
);
