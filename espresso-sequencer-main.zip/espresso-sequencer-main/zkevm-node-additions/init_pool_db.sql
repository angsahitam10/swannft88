-- Create the database for the pool. In the combined database, this DB is not
-- created via the `POSTGRES_DB` environment variable passed to the docker
-- container.
CREATE DATABASE pool_db;
